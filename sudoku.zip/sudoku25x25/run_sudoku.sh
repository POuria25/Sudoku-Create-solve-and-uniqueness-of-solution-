#!/bin/bash

# Loop through values from 0 to 99
for i in {00..03}; do
    # Format the number with leading zeros if needed
    xx=$(printf "%02d" $i)

    # Run the command with the current value of xx
    python3 sudokub.py -u "sudoku${xx}.txt"


    sleep 1
done
